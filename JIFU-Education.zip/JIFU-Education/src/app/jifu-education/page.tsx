export default function JifuPage() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-center p-24">
      <h1 className="text-4xl font-bold text-center">JIFU Education</h1>
      <p className="mt-4 text-center text-lg text-gray-600">Bem-vindo ao portal de educação JIFU!</p>
    </main>
  )
}